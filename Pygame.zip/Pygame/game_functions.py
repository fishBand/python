import sys

import pygame

from buller import Bullet

from time import sleep

from guaish import Guaish

def check_events(ai_settings,screen,stats,sb,play_botton,aotem,guaishs,bullets):
    """响应按键和鼠标事件"""
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            check_keydown_events(event,ai_settings,screen,aotem,bullets)
        elif event.type == pygame.KEYUP:
            check_keyup_events(event,aotem)
        elif event.type == pygame.  MOUSEBUTTONDOWN:
            mouse_x,mouse_y = pygame.mouse.get_pos()
            check_play_button(ai_settings,screen,stats,sb,play_botton,aotem,guaishs,bullets,mouse_x,mouse_y)


def check_play_button(ai_settings,screen,stats,sb,play_button,aotem,guaishs,bullets,mouse_x,mouse_y):
    """在玩家单击play的时候开始游戏"""
    button_clicked = play_button.rect.collidepoint(mouse_x,mouse_y)
    if button_clicked and not stats.game_active:
        #重置游戏设置
        ai_settings.initialize_dynamic_settings()

        #重置得分牌图像
        sb.prep_score()
        sb.prep_high_score()
        sb.prep_level()
        sb.prep_aotems()

        #隐藏光标
        pygame.mouse.set_visible(False)
        stats.reset_stats()
        stats.game_active = True

        #清空怪兽和子弹列表
        guaishs.empty()
        bullets.empty()

        #创建一群新的怪兽，并让奥特曼居中
        create_fleet(ai_settings,screen,aotem,guaishs)
        aotem.center_aotem()


def check_keydown_events(event,ai_settings,screen,aotem,bullets):
#当按键按住时
    if event.key == pygame.K_RIGHT:
        aotem.moving_right = True
    elif event.key == pygame.K_LEFT:
        aotem .moving_left = True
    elif event.key == pygame.K_SPACE:
        fire_bullet(ai_settings,screen,aotem,bullets)
    elif event.key == pygame.K_q:
        sys.exit()


def fire_bullet(ai_settings,screen,aotem,bullets):
#发射子弹
    if len(bullets) < ai_settings.bullets_allowed:
        new_bullet = Bullet(ai_settings, screen, aotem)
        bullets.add(new_bullet)


def check_keyup_events(event,aotem):
#当按键松开时
    if event.key == pygame.K_RIGHT:
        aotem.moving_right = False
    elif event.key == pygame.K_LEFT:
        aotem.moving_left = False


def create_fleet(ai_settings,screen,aotem,guaishs):
    """创建怪兽群"""
    #创建一个怪兽
    #它们之间的间距就为它们的宽度
    guaish = Guaish(ai_settings,screen)
    number_guaishs_x = get_number_guaishs_x(ai_settings,guaish.rect.width)
    number_rows = get_number_rows(ai_settings,aotem.rect.height,guaish.rect.height)
    # 创建第一行怪兽
    for row_number in range(number_rows):
        for guaish_number in range(number_guaishs_x):
            # 创建一个然后加进去
            create_guaish(ai_settings, screen,guaishs, guaish_number,row_number)


def get_number_rows(ai_settings,aotem_height,guaish_height):
    """计算屏幕可以容纳多少行"""
    available_space_y = (ai_settings.screen_height - (3 * guaish_height) -
                         aotem_height)
    number_rows = int(available_space_y / (2 * guaish_height))
    return number_rows


def get_number_guaishs_x(ai_settings,guaish_width):
    #计算每行可以容纳多少
    available_space_x = ai_settings.screen_width - 2 * guaish_width
    number_guaishs_x = int(available_space_x / (2 * guaish_width))
    return number_guaishs_x


def create_guaish(ai_settings,screen,guaishs,guaish_number,row_number):
    """设置一个怪兽并放在当行"""
    guaish = Guaish(ai_settings, screen)
    guaish_width = guaish.rect.width
    guaish.x = guaish_width + 2 * guaish_width * guaish_number
    guaish.rect.x = guaish.x
    guaish.rect.y = guaish.rect.height + 2 * guaish.rect.height * row_number
    guaishs.add(guaish)


def check_fleet_edges(ai_settings,guaishs):
    """有怪兽到达边缘时采取对应的措施"""
    for guaish in guaishs.sprites():
        if guaish.check_edges():
            change_fleet_direction(ai_settings,guaishs)
            break


def change_fleet_direction(ai_settings,guaishs):
    """将整体怪兽下移，并改变它们的方向"""
    for guaish in guaishs.sprites():
        guaish.rect.y += ai_settings.fleet_drop_speed
    ai_settings.fleet_direction *= -1


def update_screen(ai_settings,screen,stats,sb,aotem,guaishs,bullets,play_button):

    #更新屏幕上的图像，并切换到新屏幕
    screen.fill(ai_settings.bg_color)

    for bullet in bullets:
        bullet.draw_bullet()

    aotem.blitme()

    guaishs.draw(screen)

    # 显示得分
    sb.show_score()

    if not stats.game_active:
        play_button.draw_button()

    pygame.display.flip()


def update_bullets(ai_settings,screen,stats,sb,aotem,guaishs,bullets):
    """更新子弹位置，并删除消失的子弹"""
    #更新子弹位置
    bullets.update()

    # 删除消失的子弹
    for bullet in bullets.copy():
        if bullet.rect.bottom <= 0:
            bullets.remove(bullet)
    print(len(bullets))

    check_bullet_guaish_collisions(ai_settings,screen,stats,sb,aotem,guaishs,bullets)


def check_bullet_guaish_collisions(ai_settings,screen,stats,sb,aotem,guaishs,bullets):
    """响应子弹和怪兽碰触"""
    #删除发生碰触的怪兽和子弹
    collisions = pygame.sprite.groupcollide(bullets, guaishs, True, True)

    if collisions:
        for guaishs in collisions.values():
            stats.score += ai_settings.guaish_points * len(guaishs)
            sb.prep_score()
        check_high_score(stats,sb)

    if len(guaishs) == 0:
        #如果整群怪兽被消灭，就提高一个等级
        bullets.empty()
        ai_settings.increase_speed()

        #提高等级
        stats.level += 1
        sb.prep_level()

        create_fleet(ai_settings,screen,aotem,guaishs)


def aotem_hit(ai_settings,screen,stats,sb,aotem,guaishs,bullets):
        """响应被怪兽撞到的奥特曼"""
        if stats.aotems_left >0:
            stats.aotems_left -= 1

            #更新记分牌
            sb.prep_aotems()

            # 清空怪兽列表和子弹列表
            guaishs.empty()
            bullets.empty()

            # 创建一群新的怪兽，并将奥特曼放到屏幕底部中央
            create_fleet(ai_settings, screen, aotem, guaishs)
            aotem.center_aotem()

            #暂停
            sleep(0.5)

        else:
            stats.game_active = False
            pygame.mouse.set_visible(True)


def update_guaishs(ai_settings,screen,stats,sb,aotem,guaishs,bullets):
    """更新怪兽群中所有的怪兽位置"""
    """检查是否有怪兽处于屏幕边缘，并调整它们的位置"""
    check_fleet_edges(ai_settings, guaishs)
    guaishs.update()

    #检测怪兽和奥特曼之间的碰撞
    if pygame.sprite.spritecollideany(aotem,guaishs):
        aotem_hit(ai_settings,screen,stats,sb,aotem,guaishs,bullets)

    #检查是否有怪兽到达屏幕底端
    check_guaishs_bottom(ai_settings,screen,stats,sb,aotem,guaishs,bullets)


def check_guaishs_bottom(ai_settings,screen,stats,sb,aotem,guaishs,bullets):
    """检查是否有怪兽到达屏幕低端"""
    screen_rect = screen.get_rect()
    for guaish in guaishs.sprites():
        if guaish.rect.bottom >= screen_rect.bottom:
            #像奥特曼被撞到一样进行处理
            aotem_hit(ai_settings,screen,stats,sb,aotem,guaishs,bullets)
            break


def check_high_score(stats,sb):
    """检查是否诞生了最高分"""
    if stats.score > stats.high_score:
        stats.high_score = stats.score
        sb.prep_high_score()