import pygame

from pygame.sprite import Sprite

class Guaish(Sprite):
    """表示外星人"""
    def __init__(self,ai_settings,screen):
        """初始化外星人并设置初始位置"""
        super(Guaish,self).__init__()
        self.screen = screen
        self.ai_settings = ai_settings

        #加载外星人图像，并设置rect属性
        self.image = pygame.image.load('images/guais.bmp')
        self.rect = self.image.get_rect()

        #每个怪兽在左上角
        self.rect.x = self.rect.width
        self.rect.y = self.rect.height

        #存储怪兽的准确位置
        self.x = float(self.rect.x)

    def blitme(self):
        """在指定的位置绘制怪兽"""
        self.screen.blit(self.image,self.rect)


    def update(self):
        """向右或向左移动怪兽"""
        self.x += self.ai_settings.guaish_speed_factor * self.ai_settings.fleet_direction
        self.rect.x = self.x

    def check_edges(self):
        """如果怪兽碰到了边缘，返回Ture"""
        screen_rect = self.screen.get_rect()
        if self.rect.right >= screen_rect.right:
            return True
        elif self.rect.left <= 0:
            return True