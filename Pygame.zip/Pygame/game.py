import sys

import pygame

from pygame.sprite import Group

import game_functions as gf

from settings import Settings

from button import Button

from scoreboard import Scoreborad

from game_stats import GameStats

from guaish import Guaish

from aotem import Aotem


def run_game():
    # 初始化游戏，并创建一个窗口
    pygame.init()
    ai_settings = Settings()
    screen = pygame.display.set_mode(
        (ai_settings.screen_width, ai_settings.screen_height)
    )
    pygame.display.set_caption("Guaish Invasion")

    #创建一个奥特曼，子弹，和怪兽编组
    aotem = Aotem(ai_settings,screen)
    bullets = Group()
    guaishs = Group()

    #创建一个用于存储游戏统计信息的实例，并创建记分牌
    stats = GameStats(ai_settings)
    sb = Scoreborad(ai_settings,screen,stats)

    #怪兽群
    gf.create_fleet(ai_settings,screen,aotem,guaishs)

    #创建一个怪兽
    guaish = Guaish(ai_settings,screen)

    # 设置背景颜色
    bg_color = (230, 230, 230)

    # 创建play按钮
    play_button = Button(ai_settings, screen, "Play")

    # 游戏开始
    while True:

        # 监视键盘和鼠标事件
        gf.check_events(ai_settings,screen,stats,sb,play_button,aotem,guaishs,bullets)

        # 每次循环时都重绘屏幕
        gf.update_screen(ai_settings,screen,stats,sb,aotem,guaishs,bullets,play_button)

        if stats.game_active:
            aotem.update()

            gf.update_guaishs(ai_settings,screen,stats,sb,aotem,guaishs,bullets)

            gf.update_bullets(ai_settings,screen,stats,sb,aotem,guaishs,bullets)


run_game()
