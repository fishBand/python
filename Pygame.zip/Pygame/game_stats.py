class GameStats():
    """跟踪游戏的统计信息"""

    def __init__(self, ai_settings):
        """初始化"""
        self.ai_settings = ai_settings
        self.reset_stats()
        #游戏一开始时处于非活跃状态
        self.game_active = False
        #在任何情况下都不重置最高分
        self.high_score = 0


    def reset_stats(self):
        """初始化潜在变化对象"""
        self.aotems_left = self.ai_settings.aotem_limit
        self.score = 0
        self.level = 1