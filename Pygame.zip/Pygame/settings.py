class Settings():
    """存储游戏里的所有的类"""

    def __init__(self):
        """初始化静态数据"""
        #屏幕设置
        self.screen_width = 1200
        self.screen_height = 800
        self.bg_color = (255,255,255)

        #设置奥特曼
        self.aotem_speed_factor = 2
        self.aotem_limit = 3

        #设置怪兽
        self.guaish_speed_factor = 10
        self.fleet_drop_speed = 5
        #fleet_direction为1表示向右移，-1向左
        self.fleet_direction = 1

        #设置子弹
        self.bullet_speed_factor = 3
        self.bullet_width = 6
        self.bullet_height = 20
        self.bullet_color = 60,60,60
        self.bullets_allowed = 30

        #以什么样的速度加快游戏速度
        self.speedup_scale = 1.1
        #提高怪兽的点数
        self.score_scale = 1.5
        self.initialize_dynamic_settings()


    def initialize_dynamic_settings(self):
        """初始化因游戏进行而变化的数据"""
        self.aotem_speed_factor = 1.5
        self.bullet_speed_factor = 3
        self.guaish_speed_factor = 1
        #计分
        self.guaish_points = 50
        #fleet_direction为1表示向右，-1表示向左
        self.fleet_direction = 1


    def increase_speed(self):
        """提高速度和怪兽点数设置"""
        self.aotem_speed_factor *= self.speedup_scale
        self.bullet_speed_factor *= self.speedup_scale
        self.guaish_speed_factor *= self.speedup_scale
        self.guaishs_points = int(self.guaish_points * self.score_scale)

